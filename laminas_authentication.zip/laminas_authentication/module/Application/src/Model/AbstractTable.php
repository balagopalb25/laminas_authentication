<?php

namespace Application\Model;

use Laminas\Db\TableGateway\TableGatewayInterface;
use Application\Model\Rowset\AbstractModel;

class AbstractTable
{
    protected $tableGateway;

    public function __construct(TableGatewayInterface $tableGateway)
    {
        $this->tableGateway = $tableGateway;
        
    }


    public function saveRow(AbstractModel $userModel, $data = null)
    {
        $id = $userModel->getId();

        
        if (empty($id)) {
            $this->tableGateway->insert($data);
            return $this->tableGateway->getLastInsertValue();
        }
        if (!$this->getById($id)) {
            throw new RuntimeException(get_class($userModel) .' with id: '.$id.' not found');
        }
        $this->tableGateway->update($data, ['id' => $id]);
        return $id;
    }


    public function getTableGateway()
    {
        return $this->tableGateway;
    }
}

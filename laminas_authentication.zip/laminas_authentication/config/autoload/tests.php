<?php

$global = include __DIR__.'/global.php';
$global['db']['dsn'] = 'mysql:dbname=laminasdb_tests;host=localhost';
return $global;

-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2024 at 05:01 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laminasdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(300) NOT NULL,
  `password_salt` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_salt`) VALUES
(7, 'admin', 'admin@gmail.com', '7fc2eec212931938713b77ecf4ec588747b64daddd6b9fbd696a394ef94d953de24b776640147f285f362b330e51ada578f904520bc5f6a2615d6beaeee2306d', 'xJMq3'),
(8, 'newuser', 'newuser@gmail.com', 'd86767990549d7c9f86d9bb1e9b5ccf87e75b2f9345dbb6cda4e8363749f6151f1af8f31c903f44fa79aa70f73e36a36999d662b0e66669f04c377b838b1da12', 'mYpNEH'),
(9, 'testnew', 'testnew@gmail.com', '11b881b4eba64eefd54386c2fe870d5e3ad29b4f762800f35c64f8305eeefc1533c12b246c35145e2698050b2da02c010cdec2f42ee7c54166d0ed11467e9bb6', 'zFdtsEH'),
(10, 'nrestedf', 'nrestedf@gmail.com', 'd205de72c6cf23657b0f1781bbccb10e9554db1e748290d1d633f614d606ef4f5c45b8d442522a810b6e37cb32c14ad98da9984cb6b13963133d1936f200444b', 'efmFwcn');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
